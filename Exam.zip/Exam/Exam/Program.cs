﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Coins> lstCoins = GetCoinslist();

            //Check null count
            if (lstCoins.Count == 0)
            {
                Console.WriteLine("INSERT COIN");
            }
            if (lstCoins.Count > 0)
            {
                Console.WriteLine("Nickels:" + lstCoins[0].Nickels);
                Console.WriteLine("Dimes:" + lstCoins[0].Dimes);
                Console.WriteLine("Quarters:" + lstCoins[0].Quarters);
                Console.WriteLine("Pennies:" + lstCoins[0].Pennies);
            }
            if (lstCoins.Count > 0 && lstCoins[0].Pennies == "1/100")
            {
                lstCoins = lstCoins;
            }
            bool isinsert = InsertProducts();
            if (isinsert)
            {
                Console.WriteLine("THANK YOU", "ok");
                if (isinsert)
                {
                    Console.WriteLine("INSERT COIN");
                }
            }
        }

        public static bool InsertProducts()
        {
            Products objProducts = new Products();
            List<Products> lstProducts = new List<Products>();
            bool IsInsert = false;
            try
            {
                objProducts.Cola = "1.00";
                objProducts.Chips = "0.50";
                objProducts.Candy = "0.65";
                lstProducts.Add(objProducts);
                if (lstProducts.Count > 0)
                {
                    IsInsert = true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return IsInsert;
        }
        public static List<Coins> GetCoinslist()
        {
            Coins objCoins = new Coins();
            List<Coins> lstCoins = new List<Coins>();
            try
            {
                objCoins.Nickels = "1/20";
                objCoins.Dimes = "1/10";
                objCoins.Quarters = "1/4";
                objCoins.Pennies = "1/100";
                lstCoins.Add(objCoins);
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return lstCoins;
        }
    }
    public class Products
    {
        public string Cola { get; set; }
        public string Chips { get; set; }
        public string Candy { get; set; }
    }
    public class Coins
    {
        public string Nickels { get; set; }
        public string Dimes { get; set; }
        public string Quarters { get; set; }
        public string Pennies { get; set; }

    }

}
